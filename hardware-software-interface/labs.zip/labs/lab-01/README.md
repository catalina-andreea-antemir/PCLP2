---
nav_order: 1
parent: Labs
has_children: true
---

# Lab 1 - Number Representation

## Cloning the Repository

If you haven't already cloned the repository, do so and you are ready to go:

```console
student@hsi:~$ git clone https://github.com/cs-pub-ro/hardware-software-interface.git
student@hsi:~$ cd hardware-software-interface/labs
```
