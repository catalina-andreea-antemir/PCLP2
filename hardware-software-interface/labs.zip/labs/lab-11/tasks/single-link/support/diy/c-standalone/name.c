// SPDX-License-Identifier: BSD-3-Clause

int puts(const char *str);

int main(void)
{
	puts("Hi, my name is TODO.\n");
	return 0;
}
