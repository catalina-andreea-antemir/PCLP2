/* SPDX-License-Identifier: BSD-3-Clause */

#ifndef MIRROR_H
#define MIRROR_H	1

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define STR_SIZE 512

void mirror(char *s);

#endif /* MIRROR_H */
