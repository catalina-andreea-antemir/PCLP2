// SPDX-License-Identifier: BSD-3-Clause

#include <stdio.h>
#include "ops.h"

// Function used to validate the result.
extern void check_result(void);

int main(void)
{
	check_result();

	return 0;
}
