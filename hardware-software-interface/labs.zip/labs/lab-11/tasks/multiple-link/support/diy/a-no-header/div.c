// SPDX-License-Identifier: BSD-3-Clause

int div(int a, int b)
{
	return a / b;
}
