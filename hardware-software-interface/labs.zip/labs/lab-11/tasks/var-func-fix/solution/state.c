// SPDX-License-Identifier: BSD-3-Clause

const char *shopping_list[3];

void init_shopping(void)
{
	shopping_list[0] = "cheese";
	shopping_list[1] = "wine";
	shopping_list[2] = "dessert";
}
