---
nav_order: 4
parent: Lab 12 - CTF
has_children: true
---

# Task: Playing God

The `playing-god/support/dynamic2` binary asks you to guess a number between 1 and 100000.
Find a better way to discover it.

To help you solve this exercise, like in the previous one, make sure to [keep an eye on the registers](https://stackoverflow.com/questions/5429137/how-to-print-register-values-in-gdb)!
