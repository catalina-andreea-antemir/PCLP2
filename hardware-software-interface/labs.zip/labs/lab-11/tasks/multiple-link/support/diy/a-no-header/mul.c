// SPDX-License-Identifier: BSD-3-Clause

int mul(int a, int b)
{
	return a * b;
}
