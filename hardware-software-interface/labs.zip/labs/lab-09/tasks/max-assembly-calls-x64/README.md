---
nav_order: 8
parent: Lab 9 - The C - Assembly Interaction
---

# Task: Maximum Calculation in C with Call from Assembly - 64 Bits

Enter the directory `tasks/max-assembly-calls-x64/support` and implement the maximum calculation in C with a call from Assembly language on a 64-bit system.
Start from the program used in `tasks/max-assembly-calls`, ensuring it runs on a 64-bit system.
Follow the instructions from the previous exercise and pay attention to the order of parameters.
