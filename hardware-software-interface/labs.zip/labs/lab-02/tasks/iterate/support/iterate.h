/* SPDX-License-Identifier: BSD-3-Clause */

#ifndef ITERATE_H
#define ITERATE_H 1

void print_chars(void);
void print_shorts(void);
void print_ints(void);

#endif // ITERATE_H
