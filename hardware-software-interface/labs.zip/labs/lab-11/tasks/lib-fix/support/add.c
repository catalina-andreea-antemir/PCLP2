// SPDX-License-Identifier: BSD-3-Clause

int add(int a, int b)
{
	return a+b;
}
