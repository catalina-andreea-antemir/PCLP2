/* SPDX-License-Identifier: BSD-3-Clause */

#ifndef ARRAY_H
#define ARRAY_H 1

extern int v[5];

#endif // ARRAY_H
