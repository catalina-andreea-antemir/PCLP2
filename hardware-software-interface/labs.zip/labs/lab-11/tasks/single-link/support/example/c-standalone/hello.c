// SPDX-License-Identifier: BSD-3-Clause

int puts(const char *str);

int main(void)
{
	puts("Hello, World!\n");
	return 0;
}
