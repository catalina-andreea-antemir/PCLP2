#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>

#define LINE_SIZE 200

//Functie pentru transformarea variabilelor (a -> eax)
const char *translate_register(char variable) {
	if (variable == 'a')
		return "eax";
	if (variable == 'b')
		return "ebx";
	if (variable == 'c')
		return "ecx";
	if (variable == 'd')
		return "edx";
	return NULL;
}

//Functie pentru cazul in care functia strtok returneaza un pointer NULL
void null_case(char *token) {
	if (!token)
		exit(EXIT_FAILURE);
}

//Functie pentru verificarea cazului in care un sir este foarmat doar din cifre
int verify_if_number(char *string) {
	int i, nr = 0;
	for (i = 0; i < (int)strlen(string); i++) {
		if (string[i] >= '0' && string[i] <= '9')
			nr++;
	}
	if (nr == (int)strlen(string))
		return 1;
	return 0;
}

//In aceasta functie verific care este operatorul (+-&|^)
//pentru a afisa comanda corespunzatoare (a = a + 3 -> ADD),
//iar daca functia primeste drept parametru  '0' in loc de vreunul
//din comentariile asteptate, aceasta va stii ca este cazul comenzii MOV
void verify_mov_add_sub_log(char *var, char operator, char *expression) {
	char *command;

	if (operator != '0') {
		if (operator == '+')
			command = "ADD";
		else if (operator == '-')
			command = "SUB";
		else if (operator == '&')
			command = "AND";
		else if (operator == '|')
			command = "OR";
		else if (operator == '^')
			command = "XOR";
	} else if (operator == '0') {
		command = "MOV";
	}

	if (verify_if_number(expression) == 1) {
		printf("%s %s, %d\n", command, var, atoi(expression));
		return;
	} else if (strchr("abcd", expression[0]) != 0) {
		printf("%s %s, %s\n", command, var, translate_register(expression[0]));
		return;
	}
}

//In aceasta functie verific daca operatorul primit ca parametru
//este '*' sau '/'
void verify_mul_div(char *var, char operator, char *expression) {
	if (operator == '*') {
		//Verific cazul a = a * 3 sau a = a * b
		//unde ar trebui afisat doar MUL 3 sau MUL b,
		//care este valabil doar in cazul variabilei 'a'
		if (var[1] != 'a') {
			printf("MOV eax, %s\n", var);
			if (verify_if_number(expression) == 1) {
				printf("MUL %d\n", atoi(expression));
				printf("MOV %s, eax\n", var);
				return;
			} else if (strchr("abcd", expression[0]) != 0) {
				printf("MUL %s\n", translate_register(expression[0]));
				printf("MOV %s, eax\n", var);
				return;
			}
		} else if (verify_if_number(expression) == 1) {
			printf("MUL %d\n", atoi(expression));
			return;
		} else if (strchr("abcd", expression[0]) != 0) {
			printf("MUL %s\n", translate_register(expression[0]));
			return;
		}
	} else if (operator == '/') {
		if (verify_if_number(expression) == 1) {
			//Verific daca este cazul de immpartire la 0
			if (atoi(expression) == 0) {
				printf("Error\n");
			} else {
				printf("MOV eax, %s\n", var);
				printf("DIV %d\n", atoi(expression));
				printf("MOV %s, eax\n", var);
				return;
			}
		} else if (strchr("abcd", expression[0]) != 0) {
			printf("MOV eax, %s\n", var);
			printf("DIV %s\n", translate_register(expression[0]));
			printf("MOV %s, eax\n", var);
			return;
		}
	}
}

//Functie pentru afisarea comenzii pentru shiftarea la dreapta
void verify_shift_right(char *var, char *expression) {
	printf("SHR %s, %d\n", var, atoi(expression));
}

//Functie pentru afisarea comenzii pentru shiftarea la stanga
void verify_shift_left(char *var, char *expression) {
	printf("SHL %s, %d\n", var, atoi(expression));
}

//In aceasta functie verific operatorul primit pentru shiftare
void verify_shift(char *var, char *expression, char *operator) {
	if (strcmp(operator, "<<") == 0)
		verify_shift_left(var, expression);
	else if (strcmp(operator, ">>") == 0)
		verify_shift_right(var, expression);
}

//Functie care prelucreaza intreaga comanda
void operations(char *line) {
	char var[4], op;
	char *add_sub_log = "+-&|^", *mul_div = "*/", *shift = "<>";
	char *token1 = strtok(line, " "), *token2, *token3;

	null_case(token1);
	//Cazul atribuirii (ex: a = a + 3)
	//Voi oferii indicatii pe baza exemplului de mai sus
	//token1 = 'a'
	if (strchr("abcd", token1[0]) != 0) {
		strcpy(var, translate_register(token1[0]));
		token1 = strtok(NULL, " ");//token1 = '='
		null_case(token1);
		if (strcmp(token1, "=") == 0) {
			token1 = strtok(NULL, ";");//token1 = 'a + 3'
			null_case(token1);
			//Aici am fi intrat daca comanda era de forma 'a = 3'
			if (strchr(token1, ' ') == 0) {
				verify_mov_add_sub_log(var, '0', token1);
			} else {
				token2 = strtok(token1, " ");//token2 = 'a'
				null_case(token2);
				if (strchr("abcd", token2[0]) != 0) {
					strcpy(var, translate_register(token2[0]));
					token2 = strtok(NULL, " ");//token2 = '+'
					null_case(token2);
					if (strchr(add_sub_log, token2[0]) != 0) {
						op = token2[0];
						token2 = strtok(NULL, " ");//token2 = '3'
						null_case(token2);
						verify_mov_add_sub_log(var, op, token2);
					//Aici am fi intrat daca comanda era de forma 'a = a * 3'
					} else if (strchr(mul_div, token2[0]) != 0) {
						op = token2[0];
						token2 = strtok(NULL, " ");
						null_case(token2);
						verify_mul_div(var, op, token2);
					//Aici am fi intrat daca comanda era de forma 'a = a >> 3'
					} else if (strchr(shift, token2[0]) != 0) {
						token3 = token2;
						null_case(token3);
						token2 = strtok(NULL, ";");
						null_case(token2);
						verify_shift(var, token2, token3);
					}
				}
			}
		}
	}
}

//Functie pentru prelucrarea instructiunii if
void verify_if(char *line, int *ok_if) {
	char *token = strtok(line, " ");
	char var[4];
	char *operators = "<>=";

	null_case(token);
	//Acoperirea cazului acoladei de la finalul instructiunii if
	if (strcmp(token, "}") == 0 && *ok_if == 1) {
		printf("end_label:\n");
		*ok_if = 0;
		return;
	}
	token = strtok(NULL, " ");
	null_case(token);
	//Stergerea parantezei de la inceputul comenzii din if
	if (token[0] == '(')
		memmove(token, token + 1, strlen(token));
	//Prelucrarea comenzii din if
	if (strchr("abcd", token[0]) != 0) {
		strcpy(var, translate_register(token[0]));
		token = strtok(NULL, " ");
		null_case(token);
		if (strchr(operators, token[0]) != 0) {
			if (strcmp(token, "==") == 0) {
				token = strtok(NULL, " ");
				null_case(token);
				//Stergerea parantezei de la finalul comenzii din if
				if (token[strlen(token) - 1] == ')')
					token[strlen(token) - 1] = '\0';
				//Acoperirea fiecarui caz de JMP
				printf("CMP %s, %d\n", var, atoi(token));
				printf("JNE end_label\n");
			} else if (strcmp(token, "<=") == 0) {
				token = strtok(NULL, " ");
				null_case(token);
				if (token[strlen(token) - 1] == ')')
					token[strlen(token) - 1] = '\0';
				printf("CMP %s, %d\n", var, atoi(token));
				printf("JG end_label\n");
			} else if (strcmp(token, ">=") == 0) {
				token = strtok(NULL, " ");
				null_case(token);
				if (token[strlen(token) - 1] == ')')
					token[strlen(token) - 1] = '\0';
				printf("CMP %s, %d\n", var, atoi(token));
				printf("JL end_label\n");
			} else if (strcmp(token, "<") == 0) {
				token = strtok(NULL, " ");
				null_case(token);
				if (token[strlen(token) - 1] == ')')
					token[strlen(token) - 1] = '\0';
				printf("CMP %s, %d\n", var, atoi(token));
				printf("JGE end_label\n");
			} else if (strcmp(token, ">") == 0) {
				token = strtok(NULL, " ");
				null_case(token);
				if (token[strlen(token) - 1] == ')')
					token[strlen(token) - 1] = '\0';
				printf("CMP %s, %d\n", var, atoi(token));
				printf("JLE end_label\n");
			}
		}
	}
}

//Functie pentru prelucrarea instructiunii while
void verify_while(char *line, int *ok_while) {
	char *token = strtok(line, " ");
	char var[4];
	char *operators = "<>=";

	null_case(token);
	//Acoperirea cazului acoladei de la finalul instructiunii while
	if (*ok_while == 1 && strcmp(token, "while") == 0)
		printf("start_loop:\n");
	if (strcmp(token, "}") == 0 && *ok_while == 1) {
		printf("JMP start_loop\n");
		printf("end_label:\n");
		*ok_while = 0;
		return;
	}
	token = strtok(NULL, " ");
	null_case(token);
	//Stergerea parantezei de la inceputul comenzii din while
	if (token[0] == '(')
		memmove(token, token + 1, strlen(token));
	//Prelucrarea comenzii din while
	if (strchr("abcd", token[0]) != 0) {
		strcpy(var, translate_register(token[0]));
		token = strtok(NULL, " ");
		null_case(token);
		if (strchr(operators, token[0]) != 0) {
			if (strcmp(token, "==") == 0) {
				token = strtok(NULL, " ");
				null_case(token);
				//Stergerea parantezei de la finalul comenzii din while
				if (token[strlen(token) - 1] == ')')
					token[strlen(token) - 1] = '\0';
				//Acoperirea fiecarui caz de JMP
				printf("CMP %s, %d\n", var, atoi(token));
				printf("JNE end_label\n");
			} else if (strcmp(token, "<=") == 0) {
				token = strtok(NULL, " ");
				null_case(token);
				if (token[strlen(token) - 1] == ')')
					token[strlen(token) - 1] = '\0';
				printf("CMP %s, %d\n", var, atoi(token));
				printf("JG end_label\n");
			} else if (strcmp(token, ">=") == 0) {
				token = strtok(NULL, " ");
				null_case(token);
				if (token[strlen(token) - 1] == ')')
					token[strlen(token) - 1] = '\0';
				printf("CMP %s, %d\n", var, atoi(token));
				printf("JL end_label\n");
			} else if (strcmp(token, "<") == 0) {
				token = strtok(NULL, " ");
				null_case(token);
				if (token[strlen(token) - 1] == ')')
					token[strlen(token) - 1] = '\0';
				printf("CMP %s, %d\n", var, atoi(token));
				printf("JGE end_label\n");
			} else if (strcmp(token, ">") == 0) {
				token = strtok(NULL, " ");
				null_case(token);
				if (token[strlen(token) - 1] == ')')
					token[strlen(token) - 1] = '\0';
				printf("CMP %s, %d\n", var, atoi(token));
				printf("JLE end_label\n");
			}
		}
	}
}

//Functie pentru prelucrarea instructiunii for
void verify_for(char *line, int *ok_for, char *variable) {
	char *token1 = strtok(line, " "), *token2;
	char var[4];
	char *operators = "<>=";

	null_case(token1);
	//Acoperirea cazului acoladei de la finalul instructiunii for
	if (*ok_for == 1 && strcmp(token1, "for") == 0) {
		printf("MOV %s, 0\n", translate_register((line + 5)[0]));
		printf("start_loop:\n");
	}
	if (strcmp(token1, "}") == 0 && *ok_for == 1) {
		printf("ADD %s, 1\n", translate_register(*variable));
		printf("JMP start_loop\n");
		printf("end_loop:\n");
		*ok_for = 0;
		return;
	}
	token1 = strtok(NULL, ";");
	null_case(token1);
	//Stergerea parantezei de la inceputul comenzii din for
	if (token1[0] == '(')
		memmove(token1, token1 + 1, strlen(token1) + 1);
	//Prelucrarea comenzilor din for
	if (strchr("abcd", token1[0]) != 0) {
		strcpy(var, translate_register(token1[0]));
		*variable = var[1];
		token1 = strtok(NULL, ";");
		null_case(token1);
		token2 = strtok(token1, " ");
		null_case(token2);
		token2 = strtok(NULL, " ");
		null_case(token2);
		if (strchr(operators, token2[0]) != 0) {
			if (strcmp(token2, "<") == 0) {
				token2 = strtok(NULL, " ");
				null_case(token2);
				//Acoperirea fiecarui caz de JMP
				printf("CMP %s, %d\n", var, atoi(token2));
				printf("JGE end_label\n");
			} else if (strcmp(token2, "<=") == 0) {
				token2 = strtok(NULL, " ");
				null_case(token2);
				printf("CMP %s, %d\n", var, atoi(token2));
				printf("JG end_label\n");
			}
		}
	}
}

//Functia de baza pentru transformarea codului din C in limbaj de asamblare
void compiler(char *line, int *ok_if, int *ok_while, int *ok_for, char *var) {
	//Daca linia incepe cu una dintre variabilele a,b,c,d,
	//inseamna ca nu avem parte de vreo instructiunie de tip if, while sau for
	if (strchr("abcd", line[0]) != 0) {
		operations(line);
	//Daca linia incepe cu 'i' inseamna ca avem instructiune if
	} else if (line[0] == 'i') {
		*ok_if = 1;
		verify_if(line, ok_if);
	//Daca linia incepe cu 'w' inseamna ca avem instructiune while
	} else if (line[0] == 'w') {
		*ok_while = 1;
		verify_while(line, ok_while);
	//Daca linia incepe cu 'f' inseamna ca avem instructiune for
	} else if (line[0] == 'f') {
		*ok_for = 1;
		verify_for(line, ok_for, var);
	//Daca intalnim acolada de final de la instructiunile if, while sau for,
	//aceasta trebuie tratata in functie de instructiunea careia ii este
	//specifica, motiv pentru care folosim ok_if, ok_while si ok_for
	} else if (line[0] == '}') {
		if (*ok_if == 1)
			verify_if(line, ok_if);
		else if (*ok_while == 1)
			verify_while(line, ok_while);
		else if (*ok_for == 1)
			verify_for(line, ok_for, var);
	}
}

int main(void) {
	char line[LINE_SIZE];
	int ok_if = 0, ok_while = 0, ok_for = 0;
	char var = 'z';

	//Citesc linia de la stdin
	while (fgets(line, LINE_SIZE, stdin)) {
		//Daca linia nu este goala setam terminatorul de rand
		if (strlen(line) > 1)
			line[strlen(line) - 1] = '\0';
		//Daca linia incepe cu Tab atunci il stergem
		//ca sa putem trata linia in mod normal
		//Acest caz este pentru instructiunile din if, while si for
		if (line[0] == '\t')
			memmove(line, line + 1, strlen(line));
		compiler(line, &ok_if, &ok_while, &ok_for, &var);
	}
	return 0;
}
