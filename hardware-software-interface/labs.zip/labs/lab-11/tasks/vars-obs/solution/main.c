// SPDX-License-Identifier: BSD-3-Clause

#include <stdio.h>
#include "ops.h"

// Function used to validate the result.
extern void check_result(void);

int main(void)
{
	set(10);
	age = 33;

	check_result();

	return 0;
}
