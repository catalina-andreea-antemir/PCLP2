// SPDX-License-Identifier: BSD-3-Clause

#include "ops.h"

int sub(int a, int b)
{
	return a - b;
}
