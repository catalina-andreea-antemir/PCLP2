// SPDX-License-Identifier: BSD-3-Clause

#include "ops.h"

int add(int a, int b)
{
	return a + b;
}
