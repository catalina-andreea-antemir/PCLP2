---
nav_order: 4
parent: Lab 11 - Linking
---

# Task: Fixing the Entry Point

Access the directory `tasks/entry-fix-2/support/`.
Run the `make` command, interpret the encountered error, and resolve it by editing the `hello.c` file.

If you're having difficulties solving this exercise, go through [this](../../reading/linking.md) reading material.
