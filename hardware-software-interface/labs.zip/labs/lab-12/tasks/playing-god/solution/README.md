---
nav_order: 1
parent: 'Task: Playing God'
---

# Solution

Run the executable with GDB.
You can see the random number in the register before the input function call.

```asm
$eax   : 0x12986
$ebx   : 0x0
$ecx   : 0x12986
```
