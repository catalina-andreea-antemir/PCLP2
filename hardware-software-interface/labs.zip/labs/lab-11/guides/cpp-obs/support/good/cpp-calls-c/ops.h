/* SPDX-License-Identifier: BSD-3-Clause */

#ifndef OPS_H_
#define OPS_H_		1

#ifdef __cplusplus
extern "C" {
#endif

int add(int a, int b);
int sub(int a, int b);

#ifdef __cplusplus
}
#endif

#endif
