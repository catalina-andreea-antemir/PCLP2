/* SPDX-License-Identifier: BSD-3-Clause */

#ifndef ITERATE_REF_H
#define ITERATE_REF_H 1

void print_chars_ref(void);
void print_shorts_ref(void);
void print_ints_ref(void);

#endif // ITERATE_REF_H
