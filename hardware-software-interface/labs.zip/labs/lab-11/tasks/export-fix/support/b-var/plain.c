// SPDX-License-Identifier: BSD-3-Clause

#include <stdio.h>

static int age;

void print_age(void)
{
	printf("age: %d\n", age);
}
