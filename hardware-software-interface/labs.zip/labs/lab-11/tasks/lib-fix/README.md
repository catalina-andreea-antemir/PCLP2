---
nav_order: 9
parent: Lab 11 - Linking
---

# Task: Fixing Library Issues

Access the directory `tasks/lib-fix/support/`.
Run the `make` command, interpret the encountered error, and resolve it by editing the `Makefile`.
Refer to the `Makefile` in the directory `tasks/multiple-link/support/example/c-lib/`.

If you're having difficulties solving this exercise, go through [this](../../reading/linking.md) reading material.
