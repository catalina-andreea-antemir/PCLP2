// SPDX-License-Identifier: BSD-3-Clause

int main(void)
{
	/*
	 * TODO: Make it so you print:
	 *    price is 21
	 *    quantity is 42
	 * without directly calling a printing function.
	 */

	return 0;
}
