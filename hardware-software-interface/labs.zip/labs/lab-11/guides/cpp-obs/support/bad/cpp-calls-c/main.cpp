// SPDX-License-Identifier: BSD-3-Clause

#include <iostream>
#include "ops.h"

int main(void)
{
	std::cout << "add(10, 3): " << add(10, 3) << std::endl;
	std::cout << "sub(10, 3): " << sub(10, 3) << std::endl;

	return 0;
}
