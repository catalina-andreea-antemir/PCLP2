---
nav_order: 8
parent: Lab 6 - Structures, Vectors and Strings
---

# Guide: Students

To follow this guide, you'll need to use the `students.asm` file located in the `guides/students/support` directory.

This program iterates through the array of structures representing `students` and prints the name of each student.
