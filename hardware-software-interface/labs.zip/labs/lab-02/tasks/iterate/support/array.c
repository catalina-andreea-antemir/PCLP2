// SPDX-License-Identifier: BSD-3-Clause

#include "array.h"

int v[5] = {0xCAFEBABE, 0xDEADBEEF, 0x0B00B135, 0xBAADF00D, 0xDEADC0DE};
